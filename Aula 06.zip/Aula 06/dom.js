/* COMMANDOS DE BUSCA NO DOM*/
  // document.querySelector("SELETOR CSS");
  // document.querySelectorAll("SELETOR CSS");

  // document.children[0].children[1].children[1];
  // document.getElementsByTagName("COMANDO HTML");
  // document.getElementsByClassName("CLASSE");
  // document.getElementById("ID");
  // document.getElementsByName("NOME DO CAMPO");
  // $x("X-PATH");


/* COMANDOS COM ELEMENTOS */
  // elemento.parentNode ==> Acessa o pai do elemento
  // document.createElement("COMANDO HTML");
  // pai.appendChild(filho);
  // elemento.remove(); //CUIDADO NO IE;
  // elemento.parentNode.removeChild(elmento);

/* COMANDO DE MODIFICAÇÃO */
  // elemtno.setAttribute("ATTR","VALOR");
  // elemento.PROPRIEDADE = VALOR;
  // elemento.style["ESTILO CSS"] = VALOR;

function main(){
  var btn = document.querySelector("button#btn");
  btn.addEventListener("click",ativar);
}

function ativar(){
  var lista = document.querySelector("ol#lista");
  var texto = document.querySelector("input[name=texto]").value;
  var datas = [];
  var classe;
  
  if (validar(texto)){
	texto.split("/");
	lista.innerHTML += "<li>"+texto+"<button>X</button></li>"; 
	datas.push(texto);
	
  }
  
}

function validar(texto){
  var valido = false;
  //[TODO] => Validar se o texto é uma data;
  // EXPRESSAO REGULAR texto.match(/\d\d\d\d-\d\d-\d\d/)
  // INSTANCIAR DATA Date.parse(texto);
  // texto[0]
  // texto.split("CARACTER DE SEPARACAO")
  
  if (Date.parse(texto)){
	valido = true;  
  }
  
  
  return valido;
}

function pintaData(data, datas) {
	for(var i = 0; i < datas.length; i++){
		if(data == datas[i]){
			
		}
	}
}

window.addEventListener("load",main);